package com.example.coffeefirstsample;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.coffeefirstsample.Model.Basket;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class NotifyActivity extends AppCompatActivity implements TranslaterNotify {

    private final static String KEY_ORDER3 = "KEY_ORDER3";
    private final static String KEY_ORDER5 = "KEY_ORDER5";
    private final static String KEY_ORDER_FINAL_NOTIFY = "KEY_ORDER_FINAL_NOTIFY";
    private final static String KEY_CODE = "KEY_CODE";

    private ImageButton mButtonBack;
    private Button mTextAboutOrder;
    private List<Basket> mOrder;

    private Button mTextCode;
    private int mCode;

    private Fragment mNotifyListFragment;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notify);

        Intent intent = getIntent();
        if((List<Basket>) intent.getSerializableExtra(KEY_ORDER3) == null && (List<Basket>) intent.getSerializableExtra(KEY_ORDER5) == null){
            mOrder = new ArrayList<>();
        }else if((List<Basket>) intent.getSerializableExtra(KEY_ORDER3) != null && (List<Basket>) intent.getSerializableExtra(KEY_ORDER5) == null){
            mOrder = (List<Basket>) intent.getSerializableExtra(KEY_ORDER3);
        }else if((List<Basket>) intent.getSerializableExtra(KEY_ORDER3) == null && (List<Basket>) intent.getSerializableExtra(KEY_ORDER5) != null){
            mOrder = (List<Basket>) intent.getSerializableExtra(KEY_ORDER5);
        }

        if((List<Basket>) intent.getSerializableExtra(KEY_ORDER_FINAL_NOTIFY) != null){
            mOrder = (List<Basket>) intent.getSerializableExtra(KEY_ORDER_FINAL_NOTIFY);
        }


        mTextCode = (Button)findViewById(R.id.text_code);
        if(mOrder != null){
            if(mOrder.size() != 0 && mCode == 0){
                if (intent.getIntExtra(KEY_CODE, 0) != 0) {
                    mCode = intent.getIntExtra(KEY_CODE, 0);
                }else{
                    mCode = ThreadLocalRandom.current().nextInt(1000, 9999 + 1);
                }
                mTextCode.setVisibility(View.VISIBLE);
                mTextCode.setText(Integer.toString(mCode));
            }else{
                mTextCode.setVisibility(View.INVISIBLE);
            }
        }

        mNotifyListFragment = new NotifyListFragment();
        mTextAboutOrder = (Button) findViewById(R.id.text_about_order);
        mTextAboutOrder.setVisibility(View.INVISIBLE);
        if(mOrder != null){
            if(mOrder.size() != 0){
                mTextAboutOrder.setVisibility(View.VISIBLE);
                mTextAboutOrder.setText("Your order will be ready soon");

                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.order_container_nofity, mNotifyListFragment);
                fragmentTransaction.setTransitionStyle(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        }else{
            mTextAboutOrder.setVisibility(View.VISIBLE);
            mTextAboutOrder.setText("You haven't ordered anything yet");
        }

        mButtonBack = (ImageButton) findViewById(R.id.back_from_nofity);
        mButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NotifyActivity.this, MenuActivity.class);
                intent.putExtra(KEY_ORDER5, (Serializable) mOrder);
                intent.putExtra(KEY_CODE, mCode);
                startActivity(intent);
            }
        });

    }


    @Override
    public void translateOrderCoffee(List<Basket> order) {
        mOrder = order;
    }

    @Override
    public List<Basket> returnListCoffee() {
        return mOrder;
    }
}
