package com.example.coffeefirstsample;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.coffeefirstsample.Model.Basket;
import com.example.coffeefirstsample.Model.Coffee;
import com.example.coffeefirstsample.Model.CoffeeLab;

import java.util.ArrayList;
import java.util.List;

public class CoffeeListFragment extends Fragment{


    private List<Basket> mBasketList;

    private RecyclerView mRecyclerView;
    private CoffeeAdapter mCoffeeAdapter;

    @SuppressLint("MissingInflatedId")
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list_coffee, container, false);

        mRecyclerView = (RecyclerView) view.findViewById(R.id.list_coffee);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

         // постоянное обновление представления
        if(Return() != null){
            mBasketList = Return();
        }else{
            mBasketList = new ArrayList<>();
        }

        updateUIFragment(mBasketList);

        return view;
    }

    // класс служащий оболчкой для каждого элемента списки. функция - оптимизация
    private class CoffeeHolder extends RecyclerView.ViewHolder {

        private TextView mNameTextView;
        private TextView mCoastTextView;
        private ImageView mImageView;
        private Button mButtonBuy;
        private Coffee mCoffee;
        private List<Basket> mBasketList;
        // инициализация представления в конструкторе
        public CoffeeHolder(@NonNull LayoutInflater layoutInflater, ViewGroup parent) {
            super(layoutInflater.inflate(R.layout.item_coffee, parent, false));
            mNameTextView = (TextView) itemView.findViewById(R.id.name_text);
            mCoastTextView = (TextView) itemView.findViewById(R.id.coast_text);
            mImageView = (ImageView) itemView.findViewById(R.id.item_image);
            mButtonBuy = (Button) itemView.findViewById(R.id.button_buy);
        }
        // соединяем данные из модели кофе и ее представлением
        public void bind(Coffee coffee, List<Basket> basketList, Context context){
            mNameTextView.setText(coffee.getName());
            mCoastTextView.setText(coffee.getCoast());
            mImageView.setImageResource(coffee.getImageView());
            mCoffee = coffee;
            mBasketList = basketList;
            mButtonBuy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
                    alertDialog.setMessage("Are you sure you want to take this?");
                    alertDialog.setCancelable(true);
                    alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Basket basket = new Basket();
                            basket.setCoast(mCoffee.getCoast());
                            basket.setName(mCoffee.getName());
                            basket.setImageView(mCoffee.getImageView());
                            mBasketList.add(basket);
                            translateBack(mBasketList);
                        }
                    });
                    alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    AlertDialog dialog = alertDialog.create();
                    dialog.show();
                }
            });
        }
    }

    private class CoffeeAdapter extends  RecyclerView.Adapter<CoffeeHolder>{

        private CatalogActivity mActivity;

        private List<Coffee> mCoffees;
        private List<Basket> mBasketList;

        public CoffeeAdapter(List<Coffee> coffees, List<Basket> basketList){
            mCoffees = coffees;
            mBasketList = basketList;
            mActivity = (CatalogActivity) getActivity();
        }

        @NonNull
        @Override
        public CoffeeHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity()); // получаем layoutInflater из представления элемента
            return new CoffeeHolder(layoutInflater,parent); // создание представления элемента списка
        }

        @Override
        public void onBindViewHolder(@NonNull CoffeeHolder holder, int position) {
            Coffee coffee = mCoffees.get(position); // определения номера отображаемого элемента
            holder.bind(coffee, mBasketList, mActivity); // связывание моедли с представлением этого элемента
        }

        @Override
        public int getItemCount() {
            return mCoffees.size(); // кол-во элементов в списке, которое передается в onBingViewHolder
        }

    }

    private void updateUIFragment(List<Basket> basketList){
        CoffeeLab coffeeLab = CoffeeLab.get(getActivity()); // создание списка с кофе
        List<Coffee> coffees = coffeeLab.getCoffees(); // иницилзация списка с кофе
        mCoffeeAdapter = new CoffeeAdapter(coffees,basketList);
        mRecyclerView.setAdapter(mCoffeeAdapter);
    }

    private TranslaterCoffee mTranslaterCoffee;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try{
            mTranslaterCoffee = (TranslaterCoffee) context;
        }catch (ClassCastException e){}
    }

    @Override
    public void onDetach() {
        mTranslaterCoffee = null;
        super.onDetach();
    }

    public List<Basket> Return(){
        return mTranslaterCoffee.returnListCoffee();
    }

    public void translateBack(List<Basket> basketList){
        mTranslaterCoffee.translateOrderCoffee(basketList);
    }

}
