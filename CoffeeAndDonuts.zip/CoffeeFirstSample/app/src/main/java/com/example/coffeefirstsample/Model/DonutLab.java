package com.example.coffeefirstsample.Model;

import android.content.Context;

import com.example.coffeefirstsample.R;

import java.util.ArrayList;
import java.util.List;

public class DonutLab {

    private static DonutLab sDonutLab;

    private List<Donut> mDonuts;

    private String[] mNames = new String[]{"Chocolate", "Vanilla",
            "Strawberry","Mango"};

    private String[] mCoasts = new String[]{"0.7 $","1 $",
            "0.8 $","1.2 $",};


    private int[] mImageUrls = new int[]
            {R.drawable.chocolate,
                    R.drawable.vanilla,
                    R.drawable.strawberry,
                    R.drawable.mango};


    private DonutLab(Context context){
        mDonuts = new ArrayList<>();
        for(int i = 0; i < mNames.length; i++){
            Donut donut = new Donut();
            donut.setCoast(mCoasts[i]);
            donut.setName(mNames[i]);
            donut.setImageView(mImageUrls[i]);
            mDonuts.add(donut);
        }
    }

    public static DonutLab get(Context context){
        if(sDonutLab == null){
            sDonutLab = new DonutLab(context);
        }
        return sDonutLab;
    }

    public List<Donut> getDonuts(){
        return mDonuts;
    }

    public Donut getDonut(String name){
        for(Donut donut : mDonuts){
            if(donut.getName().equals(name)){
                return donut;
            }
        }
        return null;
    }
}
