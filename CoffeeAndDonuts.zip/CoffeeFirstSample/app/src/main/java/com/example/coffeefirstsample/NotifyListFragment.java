package com.example.coffeefirstsample;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.coffeefirstsample.Model.Basket;

import java.util.ArrayList;
import java.util.List;

public class NotifyListFragment extends Fragment {

    private TranslaterNotify mTranslaterNotify;

    private RecyclerView mRecyclerView;
    private BasketListFragment.BasketAdapter mBasketAdapter;

    private List<Basket> mBasketList;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list_nofity, container, false);

        mRecyclerView = (RecyclerView) view.findViewById(R.id.list_notify);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        updateUIFragment();

        return view;
    }

    private class NotifyHolder extends RecyclerView.ViewHolder{

        private TextView mTextName;
        private TextView mTextCoast;
        private ImageView mImageView;

        public NotifyHolder(LayoutInflater layoutInflater, ViewGroup viewGroup) {
            super(layoutInflater.inflate(R.layout.item_notify, viewGroup, false));
            mTextName = (TextView) itemView.findViewById(R.id.text_name_nofity);
            mTextCoast = (TextView) itemView.findViewById(R.id.text_coast_nofity);
            mImageView = (ImageView) itemView.findViewById(R.id.image_nofity);
        }

        public void bind(Basket basket){
            mTextName.setText(basket.getName());
            mTextCoast.setText(basket.getCoast());
            mImageView.setImageResource(basket.getImageView());
        }

    }

    private class NotifyAdapter extends RecyclerView.Adapter<NotifyHolder>{

        public NotifyAdapter(){
            if(getOrder() != null){
                mBasketList = getOrder();
            }else{
                mBasketList = new ArrayList<>();
            }
        }

        @NonNull
        @Override
        public NotifyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new NotifyHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(@NonNull NotifyHolder holder, int position) {
            Basket basket = mBasketList.get(position);
            holder.bind(basket);
            translate(mBasketList);
        }

        @Override
        public int getItemCount() {
            return mBasketList.size();
        }

        private void translate(List<Basket> list){
            mTranslaterNotify.translateOrderCoffee(list);
        }

        private List<Basket> getOrder(){
            return mTranslaterNotify.returnListCoffee();
        }

    }

    private void updateUIFragment(){
        NotifyAdapter notifyAdapter = new NotifyAdapter();
        mRecyclerView.setAdapter(notifyAdapter);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try{
            mTranslaterNotify = (TranslaterNotify) context;
        }catch (ClassCastException e){}
    }

    @Override
    public void onDetach() {
        mTranslaterNotify = null;
        super.onDetach();
    }

}
