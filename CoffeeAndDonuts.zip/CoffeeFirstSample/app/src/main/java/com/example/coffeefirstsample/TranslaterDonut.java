package com.example.coffeefirstsample;

import com.example.coffeefirstsample.Model.Basket;

import java.util.List;

public interface TranslaterDonut {
    public void translateOrderDonut(List<Basket> order);
    public List<Basket> returnListDonut();
}
