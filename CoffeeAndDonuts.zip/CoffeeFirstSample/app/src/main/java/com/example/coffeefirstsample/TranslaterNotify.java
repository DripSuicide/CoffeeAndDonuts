package com.example.coffeefirstsample;

import com.example.coffeefirstsample.Model.Basket;

import java.util.List;

public interface TranslaterNotify {
    public void translateOrderCoffee(List<Basket> order);
    public List<Basket> returnListCoffee();
}
