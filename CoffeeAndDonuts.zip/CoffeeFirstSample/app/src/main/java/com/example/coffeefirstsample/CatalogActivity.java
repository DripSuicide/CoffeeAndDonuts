package com.example.coffeefirstsample;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.coffeefirstsample.Model.Basket;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CatalogActivity extends AppCompatActivity implements TranslaterDonut, TranslaterCoffee {

    private final static String KEY_ORDER = "KEY_ORDER";
    private final static String KEY_ORDER4 = "KEY_ORDER4";
    private final static String KEY_ORDER_FINAL_CATALOG = "KEY_ORDER_FINAL_CATALOG";
    private final static String KEY_CODE = "KEY_CODE";

    private List<Basket> mBasketList;
    private List<Basket> mFinalList;

    private ImageButton mButtonBack;
    private ImageButton mButtonCoffee;
    private ImageButton mButtonDonut;
    private Button mButtonBasket;

    private Fragment mCoffeeFragment;
    private Fragment mDonutFragment;

    private int mCode;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);


        Intent intent = getIntent();

        mBasketList = (List<Basket>)intent.getSerializableExtra(KEY_ORDER);
        if((List<Basket>)intent.getSerializableExtra(KEY_ORDER) == null && (List<Basket>)intent.getSerializableExtra(KEY_ORDER4) == null){
            mBasketList = new ArrayList<>();
        }else if((List<Basket>)intent.getSerializableExtra(KEY_ORDER) == null && (List<Basket>)intent.getSerializableExtra(KEY_ORDER4) != null){
            mBasketList = (List<Basket>)intent.getSerializableExtra(KEY_ORDER4);
        }else if((List<Basket>)intent.getSerializableExtra(KEY_ORDER) != null && (List<Basket>)intent.getSerializableExtra(KEY_ORDER4) == null){
            mBasketList = (List<Basket>)intent.getSerializableExtra(KEY_ORDER);
        }

        if((List<Basket>)intent.getSerializableExtra(KEY_ORDER_FINAL_CATALOG) != null){
            mFinalList = (List<Basket>)intent.getSerializableExtra(KEY_ORDER_FINAL_CATALOG);
            mBasketList = new ArrayList<>();
        }

        if(intent.getIntExtra(KEY_CODE, 0) != 0){
            mCode = intent.getIntExtra(KEY_CODE, 0);
        }

        mButtonBack = (ImageButton) findViewById(R.id.back_from_catalog);
        mButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(CatalogActivity.this, MenuActivity.class);
                if(mFinalList != null){
                    intent1.putExtra(KEY_ORDER_FINAL_CATALOG, (Serializable) mFinalList);
                    intent1.putExtra(KEY_CODE, mCode);
                }else{
                    intent1.putExtra(KEY_ORDER4, (Serializable) mBasketList);
                }
                startActivity(intent1);
            }
        });

        mButtonBasket = (Button) findViewById(R.id.go_basket_button);
        if(mBasketList != null){
            if(mBasketList.size() > 0){
                mButtonBasket.setVisibility(View.VISIBLE);
            }else{
                mButtonBasket.setVisibility(View.INVISIBLE);
            }
        }
        mButtonBasket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(CatalogActivity.this, BasketActivity.class);
                i.putExtra(KEY_ORDER, (Serializable) mBasketList);
                startActivity(i);
            }
        });

        mCoffeeFragment = new CoffeeListFragment();
        mButtonCoffee = (ImageButton) findViewById(R.id.coffee_button);
        mButtonCoffee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.products_container, mCoffeeFragment);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                ft.addToBackStack(null);
                ft.commit();
            }
        });

        mDonutFragment = new DonutListFragment();
        mButtonDonut = (ImageButton) findViewById(R.id.donut_button);
        mButtonDonut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.products_container, mDonutFragment);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                ft.addToBackStack(null);
                ft.commit();
            }
        });
    }

    @Override
    public void translateOrderCoffee(List<Basket> order) {
        mBasketList = order;
        if(mBasketList.size() > 0){
            mButtonBasket.setVisibility(View.VISIBLE);
        }else{
            mButtonBasket.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public List<Basket> returnListCoffee() {
        return mBasketList;
    }

    @Override
    public void translateOrderDonut(List<Basket> order) {
        mBasketList = order;
        if(mBasketList.size() > 0){
            mButtonBasket.setVisibility(View.VISIBLE);
        }else{
            mButtonBasket.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public List<Basket> returnListDonut() {
        return mBasketList;
    }

    @Override
    public void onBackPressed() {
    }

}
