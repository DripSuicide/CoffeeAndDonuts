package com.example.coffeefirstsample.Model;

import java.util.UUID;

public class Donut {

    // Model of Donut

    public String mName;
    public String mCoast;
    public UUID mId;
    public int mImageView;

    public Donut() {
        mId = UUID.randomUUID();
    }

    public int getImageView() {
        return mImageView;
    }

    public void setImageView(int imageView) {
        mImageView = imageView;
    }

    public UUID getId() {
        return mId;
    }

    public void setId(UUID id) {
        mId = id;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getCoast() {
        return mCoast;
    }

    public void setCoast(String coast) {
        mCoast = coast;
    }

}
