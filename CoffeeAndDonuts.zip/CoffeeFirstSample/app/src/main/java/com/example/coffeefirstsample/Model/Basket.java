package com.example.coffeefirstsample.Model;

import java.io.Serializable;
import java.util.UUID;

public class Basket implements Serializable {

    private String mName;
    private String mCoast;
    private UUID mUUID;
    private int index;
    public int mImageView;

    public Basket(){
        mUUID = UUID.randomUUID();
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getCoast() {
        return mCoast;
    }

    public void setCoast(String coast) {
        mCoast = coast;
    }

    public UUID getUUID() {
        return mUUID;
    }

    public int getImageView() {
        return mImageView;
    }

    public void setImageView(int imageView) {
        mImageView = imageView;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

}
