package com.example.coffeefirstsample;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.coffeefirstsample.Model.Basket;
import com.example.coffeefirstsample.Model.Donut;
import com.example.coffeefirstsample.Model.DonutLab;

import java.util.ArrayList;
import java.util.List;

public class DonutListFragment extends Fragment{

    private TranslaterDonut mTranslaterDonut;
    private List<Basket> mBasketList;

    private RecyclerView mRecyclerView;
    private DonutAdapter mDonutAdapter;

    @SuppressLint("MissingInflatedId")
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list_donut, container, false);

        mRecyclerView = (RecyclerView) view.findViewById(R.id.list_donut);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        if(Return() != null){
            mBasketList = Return();
        }else{
            mBasketList = new ArrayList<>();
        }
        updateUIFragment(mBasketList);

        return view;
    }

    private class DonutHolder extends RecyclerView.ViewHolder{

        private TextView mNameTextView;
        private TextView mCoastTextView;
        private ImageView mImageView;
        private Button mButtonBuy;

        private Donut mDonut;
        private List<Basket> mBasketList;

        public DonutHolder(@NonNull LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.item_donut,parent,false));

            mNameTextView = (TextView) itemView.findViewById(R.id.name_text);
            mCoastTextView = (TextView) itemView.findViewById(R.id.coast_text);
            mImageView = (ImageView) itemView.findViewById(R.id.item_image);
            mButtonBuy = (Button) itemView.findViewById(R.id.button_buy);
        }

        public void bind(Donut donut, List<Basket> basketList, Context context){
            mNameTextView.setText(donut.getName());
            mCoastTextView.setText(donut.getCoast());
            mImageView.setImageResource(donut.getImageView());
            mDonut = donut;
            mBasketList = basketList;
            mButtonBuy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
                    alertDialog.setMessage("Are you sure you want to take this?");
                    alertDialog.setCancelable(true);

                    alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Basket basket = new Basket();
                            basket.setCoast(mDonut.getCoast());
                            basket.setName(mDonut.getName());
                            basket.setImageView(mDonut.getImageView());
                            mBasketList.add(basket);
                            translateBack(mBasketList);
                        }
                    });

                    alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });

                    AlertDialog dialog = alertDialog.create();
                    dialog.show();
                }
            });
        }
    }

    private class DonutAdapter extends RecyclerView.Adapter<DonutHolder>{

        private List<Donut> mDonuts;
        private List<Basket> mBasketList;
        private CatalogActivity mActivity;

        public DonutAdapter(List<Donut> donuts, List<Basket> basketList){
            mDonuts = donuts;
            mBasketList = basketList;
            mActivity = (CatalogActivity) getActivity();
        }

        @NonNull
        @Override
        public DonutHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(getActivity());
            return new DonutHolder(inflater, parent);
        }

        @Override
        public void onBindViewHolder(@NonNull DonutHolder holder, int position) {
            Donut donut = mDonuts.get(position);
            holder.bind(donut, mBasketList,mActivity); // связывание моедли с представлением этого элемента
        }

        @Override
        public int getItemCount() {
            return mDonuts.size();
        }

    }

    private void updateUIFragment(List<Basket> basketList){
        DonutLab donutLab = DonutLab.get(getActivity());
        List<Donut> donuts = donutLab.getDonuts();
        mDonutAdapter = new DonutAdapter(donuts, basketList);
        mRecyclerView.setAdapter(mDonutAdapter);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try{
            mTranslaterDonut = (TranslaterDonut) context;
        }catch (ClassCastException e){}
    }

    @Override
    public void onDetach() {
        mTranslaterDonut = null;
        super.onDetach();
    }

    public List<Basket> Return(){
        return mTranslaterDonut.returnListDonut();
    }

    public void translateBack(List<Basket> basketList){
        mTranslaterDonut.translateOrderDonut(basketList);
    }

}
