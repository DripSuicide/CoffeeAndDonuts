package com.example.coffeefirstsample.Model;

import android.content.Context;

import com.example.coffeefirstsample.R;

import java.util.ArrayList;
import java.util.List;

public class CoffeeLab {

    // Model of list of coffees

    private static  CoffeeLab sCoffeeLab;

    private List<Coffee> mCoffees; // list of coffee, which we'll return

    private String[] mNames = new String[]{"Latte", "Espresso",
            "Hot chocolate","Cappuccino"};

    private String[] mCoasts = new String[]{"1 $","1.2 $",
            "0.8 $","1.5 $",};


    private int[] mImageUrls = new int[]
            {R.drawable.latte,
                    R.drawable.espresso,
                    R.drawable.hotchocolate,
                    R.drawable.cappuccino};


    private CoffeeLab(Context context){
        mCoffees = new ArrayList<>();
        // here we fill list of coffees
        for(int i = 0; i< mNames.length; i++){
            Coffee coffee = new Coffee();
            coffee.setName(mNames[i]);
            coffee.setCoast(mCoasts[i]);
            coffee.setImageView(mImageUrls[i]);
            mCoffees.add(coffee);
        }
    }

    public static CoffeeLab get(Context context){
        if(sCoffeeLab == null){
            sCoffeeLab = new CoffeeLab((context));
        }
        return sCoffeeLab;
    }

    public List<Coffee> getCoffees(){
        return mCoffees;
    }

    public Coffee getCoffee(String name){
        for(Coffee coffee : mCoffees){
            if(coffee.getName().equals(name)){
                return coffee;
            }
        }
        return  null;
    }


}
