package com.example.coffeefirstsample;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

public class StartActivity extends AppCompatActivity {

    private Timer mTimer;
    private int mInterval;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        Intent intent = new Intent(StartActivity.this, MenuActivity.class);

        mInterval = 4;
        int delay = 1000;
        int period = 1000;
        mTimer = new Timer();
        mTimer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                if(mInterval == 1){
                    startActivity(intent);
                    mTimer.cancel();
                }
                mInterval--;
            }
        }, delay, period);

    }
}
