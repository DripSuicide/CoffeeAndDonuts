package com.example.coffeefirstsample;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentTransaction;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.coffeefirstsample.Model.Basket;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BasketActivity extends AppCompatActivity implements TranslaterBasket {

    private final static String KEY_ORDER = "KEY_ORDER";
    private final static String KEY_ORDER3 = "KEY_ORDER3";
    private final static String KEY_ORDER7 = "KEY_ORDER7";
    private final static String KEY_ORDER_FINAL_BASKET = "KEY_ORDER_FINAL_BASKET";
    private final static String KEY_CODE = "KEY_CODE";

    private ImageButton mButtonBack;
    private Button mButtonNewOrder;
    protected Button mButtonPay;
    protected Button mButtonClear;

    private Fragment basketListFragment;

    private List<Basket> mOrder;
    private List<Basket> mFinalList;
    private int mCode;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basket);

        Intent intent = getIntent();
        if((List<Basket>)intent.getSerializableExtra(KEY_ORDER) == null && (List<Basket>)intent.getSerializableExtra(KEY_ORDER7) == null){
            mOrder = new ArrayList<>();
        }else if((List<Basket>)intent.getSerializableExtra(KEY_ORDER) == null && (List<Basket>)intent.getSerializableExtra(KEY_ORDER7) != null){
            mOrder = (List<Basket>)intent.getSerializableExtra(KEY_ORDER7);
        }else if((List<Basket>)intent.getSerializableExtra(KEY_ORDER) != null && (List<Basket>)intent.getSerializableExtra(KEY_ORDER7) == null){
            mOrder = (List<Basket>)intent.getSerializableExtra(KEY_ORDER);
        }

        if((List<Basket>)intent.getSerializableExtra(KEY_ORDER_FINAL_BASKET) != null){
            mFinalList = (List<Basket>)intent.getSerializableExtra(KEY_ORDER_FINAL_BASKET);
            mOrder = new ArrayList<>();
        }

        if(intent.getIntExtra(KEY_CODE, 0) != 0){
            mCode = intent.getIntExtra(KEY_CODE, 0);
        }

        basketListFragment = new BasketListFragment();
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.replace(R.id.products_container_basket, basketListFragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.addToBackStack(null);
        ft.commit();

        mButtonBack = (ImageButton) findViewById(R.id.back_from_basket);
        mButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(BasketActivity.this, MenuActivity.class);
                if(mFinalList != null){
                    intent1.putExtra(KEY_ORDER_FINAL_BASKET, (Serializable) mFinalList);
                    intent1.putExtra(KEY_CODE, mCode);
                }else{
                    intent1.putExtra(KEY_ORDER7, (Serializable) mOrder);
                }
                startActivity(intent1);
            }
        });

        mButtonNewOrder = (Button) findViewById(R.id.new_order_button);
        mButtonNewOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mOrder = new ArrayList<>();
                Intent i = new Intent(BasketActivity.this, CatalogActivity.class);
                i.putExtra(KEY_ORDER, (Serializable)mOrder);
                startActivity(i);
            }
        });

        mButtonPay = (Button) findViewById(R.id.pay_button);
        if(mOrder != null){
            if(mOrder.size() > 0){
                mButtonPay.setVisibility(View.VISIBLE);
            }
        }else{
            mButtonPay.setVisibility(View.INVISIBLE);
        }
        mButtonPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(BasketActivity.this);
                alertDialog.setMessage("Are you sure you want to place an order?");
                alertDialog.setCancelable(true);

                alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(BasketActivity.this, NotifyActivity.class);
                        i.putExtra(KEY_ORDER3,(Serializable) mOrder);
                        startActivity(i);
                        mOrder = new ArrayList<>();
                        dialog.cancel();
                    }
                });

                alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                AlertDialog dialog = alertDialog.create();
                dialog.show();
            }
        });


        mButtonClear = (Button) findViewById(R.id.clear_button);
        if(mOrder != null){
            if(mOrder.size() > 0){
                mButtonClear.setVisibility(View.VISIBLE);
            }
        }else{
            mButtonClear.setVisibility(View.INVISIBLE);
        }

    }

    @Override
    public void translateOrderBasket(List<Basket> order) {
        mOrder = order;
    }
    
    @Override
    public List<Basket> returnListBasket() {
        return mOrder;
    }

    @Override
    public BasketActivity returnActivity(){
        return BasketActivity.this;
    }

    @Override
    public void onBackPressed() {
    }

}
