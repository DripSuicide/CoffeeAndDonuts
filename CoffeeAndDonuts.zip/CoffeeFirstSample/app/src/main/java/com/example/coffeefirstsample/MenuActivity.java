package com.example.coffeefirstsample;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.coffeefirstsample.Model.Basket;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MenuActivity extends AppCompatActivity {

    private ImageButton mButtonBasket;
    private ImageButton mButtonNotify;
    private ImageButton mButtonCatalog;

    private final static String KEY_ORDER4 = "KEY_ORDER4";
    private final static String KEY_ORDER5 = "KEY_ORDER5";
    private final static String KEY_ORDER7 = "KEY_ORDER7";
    private final static String KEY_ORDER_FINAL_CATALOG = "KEY_ORDER_FINAL_CATALOG";
    private final static String KEY_ORDER_FINAL_BASKET = "KEY_ORDER_FINAL_BASKET";
    private final static String KEY_ORDER_FINAL_NOTIFY = "KEY_ORDER_FINAL_NOTIFY";
    private final static String KEY_CODE = "KEY_CODE";

    private List<Basket> mBasketList;
    private List<Basket> mFinalList;

    private int mCode;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Intent intent = getIntent();
        if((List<Basket>) intent.getSerializableExtra(KEY_ORDER4) == null &&
                (List<Basket>) intent.getSerializableExtra(KEY_ORDER7) == null
                && (List<Basket>) intent.getSerializableExtra(KEY_ORDER5) == null){

            mBasketList = new ArrayList<>();

        }else if((List<Basket>) intent.getSerializableExtra(KEY_ORDER4) != null
                && (List<Basket>) intent.getSerializableExtra(KEY_ORDER7) == null
                && (List<Basket>) intent.getSerializableExtra(KEY_ORDER5) == null){

            mBasketList = (List<Basket>) intent.getSerializableExtra(KEY_ORDER4);

        }else if((List<Basket>) intent.getSerializableExtra(KEY_ORDER4) == null
                && (List<Basket>) intent.getSerializableExtra(KEY_ORDER7) != null
                && (List<Basket>) intent.getSerializableExtra(KEY_ORDER5) == null){

            mBasketList = (List<Basket>) intent.getSerializableExtra(KEY_ORDER7);

        }else if((List<Basket>) intent.getSerializableExtra(KEY_ORDER4) == null
                && (List<Basket>) intent.getSerializableExtra(KEY_ORDER7) == null
                && (List<Basket>) intent.getSerializableExtra(KEY_ORDER5) != null){

            mBasketList = (List<Basket>) intent.getSerializableExtra(KEY_ORDER5);
            mFinalList = mBasketList;
        }

        if((List<Basket>) intent.getSerializableExtra(KEY_ORDER_FINAL_CATALOG) != null){
            mFinalList = (List<Basket>) intent.getSerializableExtra(KEY_ORDER_FINAL_CATALOG);
        }

        if((List<Basket>) intent.getSerializableExtra(KEY_ORDER_FINAL_BASKET) != null){
            mFinalList = (List<Basket>) intent.getSerializableExtra(KEY_ORDER_FINAL_BASKET);
        }

        if(intent.getIntExtra(KEY_CODE, 0) != 0){
            mCode = intent.getIntExtra(KEY_CODE, 0);
        }

        mButtonCatalog = (ImageButton) findViewById(R.id.catalog_button);
        mButtonCatalog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuActivity.this, CatalogActivity.class);
                if(mFinalList != null){
                    i.putExtra(KEY_ORDER_FINAL_CATALOG, (Serializable) mFinalList);
                    i.putExtra(KEY_CODE, mCode);
                }else{
                    i.putExtra(KEY_ORDER4, (Serializable) mBasketList);
                }
                startActivity(i);
            }
        });

        mButtonBasket = (ImageButton) findViewById(R.id.basket_button);
        mButtonBasket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuActivity.this, BasketActivity.class);
                if(mFinalList != null){
                    i.putExtra(KEY_ORDER_FINAL_BASKET, (Serializable) mFinalList);
                    i.putExtra(KEY_CODE, mCode);
                }else{
                    i.putExtra(KEY_ORDER7, (Serializable) mBasketList);
                }
                startActivity(i);
            }
        });

        mButtonNotify = (ImageButton) findViewById(R.id.nofity_button);
        mButtonNotify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MenuActivity.this, NotifyActivity.class);
                if(mFinalList != null){
                    intent1.putExtra(KEY_ORDER_FINAL_NOTIFY, (Serializable) mFinalList);
                    intent1.putExtra(KEY_CODE, mCode);
                }else{
                    intent1.putExtra(KEY_ORDER5, (Serializable) mBasketList);
                }
                startActivity(intent1);
            }
        });

    }

    @Override
    public void onBackPressed() {
    }

}
