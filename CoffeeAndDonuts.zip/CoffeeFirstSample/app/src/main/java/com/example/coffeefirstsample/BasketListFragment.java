package com.example.coffeefirstsample;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.coffeefirstsample.Model.Basket;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

public class BasketListFragment extends Fragment{

    private TranslaterBasket mTranslaterBasket;

    private RecyclerView mRecyclerView;
    private BasketAdapter mBasketAdapter;

    private List<Basket> mBasketList;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.list_basket, container, false);

        mRecyclerView = (RecyclerView) view.findViewById(R.id.list_basket);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        updateUIFragment();

        return view;
    }

    private class BasketHolder extends RecyclerView.ViewHolder{

        private TextView mNameTextView;
        private TextView mCoastTextView;
        private Button mDeleteButton;
        private ImageView mImageView;

        public BasketHolder(@NonNull LayoutInflater layoutInflater, ViewGroup parent){
            super(layoutInflater.inflate(R.layout.item_basket, parent, false));
            mNameTextView = (TextView) itemView.findViewById(R.id.text_name_nofity);
            mCoastTextView = (TextView) itemView.findViewById(R.id.text_coast_nofity);
            mDeleteButton = (Button) itemView.findViewById(R.id.delete_button);
            mImageView = (ImageView) itemView.findViewById(R.id.image_nofity);
        }

        public void bind(Basket basket){
            mNameTextView.setText(basket.getName());
            mCoastTextView.setText(basket.getCoast());
            mImageView.setImageResource(basket.getImageView());
        }

    }

    protected class BasketAdapter extends RecyclerView.Adapter<BasketHolder>{

        private BasketActivity mActivity;
        private Button ButtonClear;
        private Button ButtonPay;
        private Button TextTotal;

        private Double coast;
        public BasketAdapter(){
            if (getOrder() != null){
                mBasketList = getOrder();
            }else{
                mBasketList= new ArrayList<>();
            }
            mActivity = getActivity();
            TextTotal = (Button) mActivity.findViewById(R.id.total_text_basket);
            ButtonClear = mActivity.mButtonClear = (Button) mActivity.findViewById(R.id.clear_button);
            if(mBasketList != null){
                if(mBasketList.size() != 0){
                    ButtonClear.setVisibility(View.VISIBLE);
                    TextTotal.setVisibility(View.VISIBLE);
                }
            }else{
                ButtonClear.setVisibility(View.INVISIBLE);
                TextTotal.setVisibility(View.INVISIBLE);
                ButtonPay.setVisibility(View.INVISIBLE);
            }
            ButtonPay = mActivity.mButtonPay = (Button) mActivity.findViewById(R.id.pay_button);
            coast = CountMainCoast();
        }

        @NonNull
        @Override
        public BasketHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new BasketHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(@NonNull BasketHolder holder, int position) {
            int now = position;
            Basket basket = mBasketList.get(now);
            holder.bind(basket);
            if(mBasketList != null){
                if(mBasketList.size() != 0){
                    TextTotal.setText("Total: " + coast + " $");
                }else{
                    TextTotal.setVisibility(View.INVISIBLE);
                }
            }
            holder.mDeleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    removeBasket(now);
                }
            });

            ButtonClear.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    RemoveAll();
                    translate(mBasketList);
                    ButtonClear.setVisibility(View.INVISIBLE);
                    ButtonPay.setVisibility(View.INVISIBLE);
                    TextTotal.setVisibility(View.INVISIBLE);
                }
            });
            translate(mBasketList);
        }

        @Override
        public int getItemCount() {
            return mBasketList.size();
        }


        public void removeBasket(int position){
            String number = mBasketList.get(position).getCoast();
            String number2 = number.replace(",",".");
            String numberAr = number2.replace(" $", "");
            BigDecimal s = new BigDecimal(coast);
            BigDecimal f = new BigDecimal(Double.parseDouble(numberAr));
            coast = Double.parseDouble(s.subtract(f).setScale(1, RoundingMode.HALF_UP).toString());
            if(coast != 0.0){
                TextTotal.setText("Total: " + Double.toString(coast) + " $");
            }else{
                TextTotal.setVisibility(View.INVISIBLE);
                ButtonPay.setVisibility(View.INVISIBLE);
                ButtonClear.setVisibility(View.INVISIBLE);
            }
            mBasketList.remove(position);
            if(!mRecyclerView.isComputingLayout() && mRecyclerView.getScrollState() == RecyclerView.SCROLL_STATE_IDLE){
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, mBasketList.size());
            }
        }

        public void RemoveAll(){
            for(int i = mBasketList.size() - 1; i >= 0; i--){
                mBasketList.remove(i);
                if(!mRecyclerView.isComputingLayout() && mRecyclerView.getScrollState() == RecyclerView.SCROLL_STATE_IDLE){
                    notifyItemRemoved(i);
                    notifyItemRangeChanged(i, mBasketList.size());
                }
            }
        }

        public Double CountMainCoast(){
            Double sum = 0.0;
            for(int i = 0; i < mBasketList.size(); i++){
                String number = mBasketList.get(i).getCoast();
                String number2 = number.replace(",",".");
                String numberAr = number2.replace(" $", "");
                BigDecimal s = new BigDecimal(sum);
                BigDecimal f = new BigDecimal(Double.parseDouble(numberAr));
                sum = Double.parseDouble(s.add(f).setScale(1, RoundingMode.HALF_UP).toString());
            }
            return sum;
        }

        public void translate(List<Basket> basketList){
            mTranslaterBasket.translateOrderBasket(basketList);
        }

        public List<Basket> getOrder(){
            return mTranslaterBasket.returnListBasket();
        }

        public BasketActivity getActivity(){
            return mTranslaterBasket.returnActivity();
        }
    }

    public void updateUIFragment(){
        mBasketAdapter = new BasketAdapter();
        mRecyclerView.setAdapter(mBasketAdapter);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try{
            mTranslaterBasket = (TranslaterBasket) context;
        }catch (ClassCastException e){}
    }

    @Override
    public void onDetach() {
        mTranslaterBasket = null;
        super.onDetach();
    }

}
