package com.example.coffeefirstsample;

import com.example.coffeefirstsample.Model.Basket;

import java.util.List;

public interface TranslaterBasket {
    public void translateOrderBasket(List<Basket> order);
    List<Basket> returnListBasket();
    BasketActivity returnActivity();
}
